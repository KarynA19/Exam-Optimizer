from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import Response

from app.models.schedule import CourseImportResponse, ManualMoveRequest, ScheduleProject, SolveRequest, ValidationIssue
from app.services.course_import import CourseImportError, export_course_template_excel, import_courses_from_excel
from app.services.solver import solve_project
from app.services.validation import explain_manual_move, validate_manual_move, validate_project

router = APIRouter(tags=["projects"])


@router.post("/projects/validate", response_model=ScheduleProject)
def validate_schedule_project(project: ScheduleProject) -> ScheduleProject:
    issues = validate_project(project)
    return project.model_copy(update={"issues": issues})


@router.post("/projects/solve")
def solve_schedule_project(request: SolveRequest) -> dict:
    issues = validate_project(request.project)
    blocking_issues = [issue for issue in issues if issue.severity == "error"]
    if blocking_issues:
        raise HTTPException(status_code=422, detail=[issue.model_dump(mode="json") for issue in blocking_issues])
    return solve_project(request)


@router.post("/projects/manual-move")
def validate_schedule_move(request: ManualMoveRequest) -> dict:
    return validate_manual_move(request)


@router.post("/projects/explain-move")
def explain_schedule_move(request: ManualMoveRequest) -> dict:
    return explain_manual_move(request)


@router.post("/projects/import-courses", response_model=CourseImportResponse)
async def import_project_courses(file: UploadFile = File(...)) -> CourseImportResponse:
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        issue = ValidationIssue(
            code="invalid_import_file",
            severity="error",
            message="Please upload a .xlsx file that matches the course import template.",
        )
        raise HTTPException(status_code=422, detail=[issue.model_dump(mode="json")])

    content = await file.read()

    try:
        return import_courses_from_excel(content)
    except CourseImportError as error:
        raise HTTPException(status_code=422, detail=[issue.model_dump(mode="json") for issue in error.issues]) from error


@router.get("/projects/import-courses/template")
def download_course_template() -> Response:
    content = export_course_template_excel()
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": 'attachment; filename="course-import-template.xlsx"',
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )
